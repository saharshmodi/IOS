//
//  ViewController.swift
//  PlistDemoWithArrayAndDic
//
//  Created by TOPS on 10/9/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtrno: UITextField!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var txtlname: UITextField!
    @IBOutlet weak var txtcourse: UITextField!
    var arrdic:[Any] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btncreateplist(_ sender: Any) {
        
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        let strpath = arr[0] as! String
        
        let fullpath = strpath.appending("/Record.plist")
        
        print(fullpath)
        
        let fmg = FileManager()
        
        if !fmg.fileExists(atPath: fullpath)
        {
            let dic1 = ["Roll_No":txtrno.text!,"Fname":txtfname.text!,"Lname":txtlname.text!,"Course":txtcourse.text!]
            arrdic.append(dic1)
            
            let dic = ["Record":arrdic]
            
            let finadic = NSDictionary(dictionary: dic)
            
            finadic.write(toFile: fullpath, atomically: true)
            
        }
        else
        {
            var fatchdic = NSDictionary(contentsOfFile: fullpath)
            
            var fatcharr = fatchdic?["Record"] as! [Any]
            
            let dic1 = ["Roll_No":txtrno.text!,"Fname":txtfname.text!,"Lname":txtlname.text!,"Course":txtcourse.text!]
            
            fatcharr.append(dic1)
            
            let dic2 = ["Record":fatcharr]
            
            let newdic = NSDictionary(dictionary: dic2)
            
            newdic.write(toFile: fullpath, atomically: true)
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

