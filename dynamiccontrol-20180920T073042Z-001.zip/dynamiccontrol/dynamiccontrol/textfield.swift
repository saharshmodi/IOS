//
//  textfield.swift
//  dynamiccontrol
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class textfield: NSObject
{
    func tbcreate(frm:CGRect,placeholder:String,bc:UIColor,bw:Int) -> UITextField
    {
        let txt = UITextField(frame: frm);
        txt.placeholder = placeholder;
        txt.layer.cornerRadius = 10;
        txt.layer.borderColor = bc.cgColor;
        txt.layer.borderWidth = CGFloat(bw);
        return txt;
    }
    func tbcreatewithimg(frm:CGRect,placeholder:String?,bc:UIColor,bw:Int) -> UITextField
    {
        let txt = UITextField(frame: frm);
        txt.placeholder = placeholder;
        let border = CALayer();
        let width = CGFloat(2.0);
        border.borderColor = bc.cgColor;
        border.frame = CGRect(x: 0, y: txt.frame.size.height-width, width: txt.frame.size.width, height: txt.frame.size.height);
        let imgview = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height: 30));
        imgview.image = UIImage(named: "icon.jpg");
        txt.leftViewMode = .always;
        txt.leftView = imgview;
        border.borderWidth = width;
        txt.layer.addSublayer(border);
        txt.layer.masksToBounds = true;
        return txt;
    }

}
