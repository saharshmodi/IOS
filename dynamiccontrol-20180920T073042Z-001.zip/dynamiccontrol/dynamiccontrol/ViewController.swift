//
//  ViewController.swift
//  dynamiccontrol
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let comm = common();
        let src = UIScrollView(frame: self.view.bounds);
        var y = 20
        for i in 0 ... 10
        {
            let btn = comm.createbtn(frm: CGRect(x: 20, y: y, width: 100, height: 100), img: UIImage(named: "icon.jpg")!)
            btn.tag = i;
            btn.addTarget(self, action: #selector(self.test), for: .touchUpInside);
            src.addSubview(btn);
            y = y + 120;
         }
        src.contentSize = CGSize(width: self.view.frame.size.width, height: CGFloat(y));
        self.view.addSubview(src);
    }
        // Do any additional setup after loading the view, typically from a nib.
        
            /*func btncreate()
    {
        let btn = UIButton(type: .custom);
        btn.frame = CGRect(x: 20, y: 30, width: 100, height: 100);
        btn.setImage(UIImage(named:"icon.jpg"), for: .normal);
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside);
        self.view.addSubview(btn);
    }*/
    func test(sender:UIButton)
    {
        print(sender.tag);
        print("Clicked");
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

