//
//  common.swift
//  dynamiccontrol
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class common: NSObject
{
    func createbtn(frm:CGRect,img:UIImage) -> UIButton
    {
        let btn = UIButton(type: .custom);
        btn.frame = frm;
        btn.setImage(img, for: .normal);
        return btn;
    }
}
