//
//  ViewControllertextfield.swift
//  dynamiccontrol
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewControllertextfield: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*let tb = textfield();
        let txt = tb.tbcreate(frm: CGRect(x: 10, y: 40, width: 200, height: 50), placeholder: "User Name :", bc: UIColor.blue, bw: 1);
        txt.addTarget(self, action: #selector(self.test1), for: .editingChanged);
        self.view.addSubview(txt);*/
        
        let tb = textfield();
        let text = tb.tbcreatewithimg(frm: CGRect(x: 10, y: 40, width: 200, height: 40), placeholder: nil, bc: UIColor.blue, bw: 4);
        text.addTarget(self, action: #selector(self.test1), for: .editingChanged);
        self.view.addSubview(text);
    
        // Do any additional setup after loading the view.
    }
    func test1(sender:UITextField)
    {
        print(sender.text!);
    }

        override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
