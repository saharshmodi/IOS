//
//  emp.swift
//  MVCDemo
//
//  Created by MAC2 on 30/10/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class emp: NSObject
{
    var ename:String?;
    var phno:String?;
    var email:String?;
    var pass:String?;
    
    init(ename:String,phno:String,email:String,pass:String)
    {
        self.ename = ename;
        self.phno = phno;
        self.email = email;
        self.pass = pass;
    }
}
