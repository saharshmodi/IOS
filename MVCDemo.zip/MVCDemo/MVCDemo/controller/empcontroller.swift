//
//  empcontroller.swift
//  MVCDemo
//
//  Created by MAC2 on 30/10/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

protocol empdelegate
{
    func getdata(str:String)
}
class empcontroller: NSObject
{
    var delegate:empdelegate?;
    
    func insertemp(obj:emp,url:String)
    {
        
        let str = "name=\(obj.ename!)&phno=\(obj.phno!)&email=\(obj.email!)&pass=\(obj.pass!)";
        let strurl = "\(url)?\(str)"
        let finalurl = URL(string: strurl);
        let request = URLRequest(url: finalurl!);
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request)
        {
            (data1, resp, err) in
            DispatchQueue.main.async
            {
               let strresp = String(data: data1!, encoding: String.Encoding.utf8);
                self.delegate?.getdata(str: strresp!);
            }
            
        }
        datatask.resume();
        
    }
}
