//
//  ViewController.swift
//  MVCDemo
//
//  Created by MAC2 on 30/10/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController,empdelegate
{
    func getdata(str: String)
    {
        print(str);
    }
    

    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var txt3: UITextField!
    @IBOutlet weak var txt4: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btninsert(_ sender: Any)
    {
        let obj = emp(ename: txt1.text!, phno: txt2.text!, email: txt3.text!, pass: txt4.text!);
        let main = empcontroller();
        main.delegate = self;
        main.insertemp(obj: obj, url: "http://localhost/project/index.php");
    }
    
}

