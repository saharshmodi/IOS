//
//  ViewController.swift
//  TextFieldUsingThirdParty1
//
//  Created by TOPS on 9/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects


class ViewController: UIViewController
{
    var txt = KaedeTextField()
    var txt1 = HoshiTextField()
    var txt2  = JiroTextField()
    var txt3 = IsaoTextField()
    var txt4 = AkiraTextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let frm = CGRect(x: 50, y: 50, width: 100, height: 30);
        txt = KaedeTextField(frame: frm);
        txt.placeholder = "Enter Name";
        txt.placeholderColor = .darkGray;
        txt.foregroundColor = .yellow;
        self.view.addSubview(txt);
        
        let frm1 = CGRect(x: 50, y: 100, width: 100, height: 60);
        txt1 = HoshiTextField(frame: frm1);
        txt1.placeholder = "Enter City";
        txt1.placeholderColor = .cyan;
        txt1.placeholderFontScale = .abs(1.0);
        let border = CALayer()
        let width = CGFloat(2.0);
        border.borderColor = UIColor.blue.cgColor;
        border.frame = CGRect(x: 0, y: txt1.frame.size.height-width, width: txt1.frame.size.width, height: txt1.frame.size.height)
        border.borderWidth = width;
        txt1.layer.addSublayer(border);
        txt1.layer.masksToBounds = true;
        self.view.addSubview(txt1);
        
        
        let frm2 = CGRect(x: 50, y: 200, width: 150, height: 60);
        txt2 = JiroTextField(frame: frm2);
        txt2.placeholder = "Enter Mobile No :";
        txt2.placeholderColor = .darkGray;
        txt2.placeholderFontScale = .abs(1.0);
        txt2.tintColor = .blue;
        let border1 = CALayer()
        let width1 = CGFloat(3.0);
        border1.borderColor = UIColor.cyan.cgColor;
        border1.frame = CGRect(x: 0, y: txt2.frame.size.height-width, width: txt2.frame.size.width, height: txt2.frame.size.height)
        border1.borderWidth = width1;
        txt2.layer.addSublayer(border1);
        txt2.layer.masksToBounds = true;
        self.view.addSubview(txt2);
        
        let frm3 = CGRect(x: 50, y: 250, width: 150, height: 60);
        txt3 = IsaoTextField(frame: frm3);
        txt3.placeholder = "Enter Email Id";
        txt3.placeholderFontScale = .abs(1.0);
        txt3.tintColor = .red;
        let border2 = CALayer()
        let width2 = CGFloat(3.0);
        border2.borderColor = UIColor.red.cgColor;
        border2.frame = CGRect(x: 0, y: txt3.frame.size.height-width, width: txt3.frame.size.width, height: txt3.frame.size.height)
        border2.borderWidth = width2;
        txt3.layer.addSublayer(border2);
        txt3.layer.masksToBounds = true;
        self.view.addSubview(txt3);
        
        let frm4 = CGRect(x: 50, y: 300, width: 150, height: 60);
        txt4 = AkiraTextField(frame: frm4);
        txt4.placeholder = "Enter password"
        txt4.placeholderColor = .gray
        self.view.addSubview(txt4)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

