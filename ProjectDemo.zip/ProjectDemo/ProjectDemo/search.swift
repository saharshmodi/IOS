//
//  search.swift
//  ProjectDemo
//
//  Created by TOPS on 10/15/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class search: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 60))
        
        let navitem = UINavigationItem(title: "Search")
        
        let item1 = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(self.home))
        let item2 = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(self.search))
        
        navitem.rightBarButtonItem = item2
        navitem.leftBarButtonItem = item1
        
        navbar.items = [navitem]
        self.view.addSubview(navbar)
        
    }

    func home(sender:UIBarButtonItem)  {
    
    }
    
    func search(sender:UIBarButtonItem)  {
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
