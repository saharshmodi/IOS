//
//  custcell.swift
//  tableviewdemo
//
//  Created by TOPS on 9/5/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var img: UIImageView!

    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var lbl: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
