//
//  ViewController.swift
//  tableviewdemo
//
//  Created by TOPS on 9/5/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    var arr = ["ios","mac","apple"];
    var img = ["surat1.jpg","3.png","images.jpeg"];
    
    @IBOutlet weak var tblview: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //To create tableview dynamically
        
        /*let tbl = UITableView(frame: self.view.bounds, style: .grouped);
        tbl.delegate = self;
        tbl.dataSource = self;
        self.view.addSubview(tbl);*/
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        //To create tableview dynamically
        //tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell");
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell;
        cell.lbl.text = arr[indexPath.row];
        cell.img?.image = UIImage(named: img[indexPath.row]);
        cell.btn.addTarget(self, action: #selector(self.test1), for: .touchUpInside);
        cell.btn.tag = indexPath.row;
        cell.accessoryType = .detailDisclosureButton;
        
        let imgview = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20));
        imgview.image = UIImage(named: img[indexPath.row]);
        cell.accessoryView = imgview;
        
        return cell;
        
    }
    func test1(sender:UIButton)
    {
        print(arr[sender.tag]);
        
        let index = IndexPath(row: sender.tag, section: 0);
        let cell = tblview.cellForRow(at: index)as!custcell;
        print(cell.lbl.text);
    }
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath)
    {
        print(indexPath.row);
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print(arr[indexPath.row]);
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        arr.remove(at: indexPath.row);
        tableView.reloadData();
    }
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle
    {
        if indexPath.row == 1
        {
            return UITableViewCellEditingStyle.none;
        }
        else
        {
            return UITableViewCellEditingStyle.delete;
        }
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        let ok = UITableViewRowAction(style: .default, title: "Ok")
        {
            (action,index) in
        }
        let cancel = UITableViewRowAction(style: .default, title: "Cancel")
        {
            (action,index) in
        }
        return [ok,cancel];
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 150;
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 100;
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 100;
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return "saharsh";
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String?
    {
        return "Modi";
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100));
        let btn = UIButton(type: .roundedRect);
        btn.frame = CGRect(x: 10, y: 10, width: 150, height: 70);
        btn.setTitle("Click", for: .normal);
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside);
        v1.addSubview(btn);
        v1.backgroundColor = UIColor.blue;
        return v1;
    }
    func test(sender:UIButton)
    {
        print("Click");
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100));
        v1.backgroundColor = UIColor.cyan;
        return v1;
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

