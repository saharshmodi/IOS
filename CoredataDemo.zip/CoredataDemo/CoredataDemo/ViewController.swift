//
//  ViewController.swift
//  CoredataDemo
//
//  Created by Mac on 10/10/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext;
    
    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var txt3: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func btninsert(_ sender: Any)
    {
        let entity = NSEntityDescription.insertNewObject(forEntityName:"Emp", into: context);
        
        entity.setValue(txt1.text, forKey: "emp_name");
        entity.setValue(txt2.text, forKey: "emp_add");
        entity.setValue(txt3.text, forKey: "emp_mob");
        
        do
        {
            try context.save()
            clear();
        }
        catch
        {
        }
    }

    func clear()
    {
        
        txt1.text = "";
        txt2.text = "";
        txt3.text = "";
        
        txt1.becomeFirstResponder();
        
    }

    @IBAction func btnupdate(_ sender: Any)
    {
        let entity1 = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = entity1;
        
        let pred = NSPredicate(format: "emp_add =%@", txt2.text!);
        
        request.predicate = pred;
        
        
        do {
            var arr  = try context.fetch(request);
            
            
            if arr.count > 0 {
                
                let obj = arr[0] as! NSManagedObject;
                
                obj.setValue(txt1.text!, forKey: "emp_name");
                obj.setValue(txt2.text!, forKey: "emp_add");
                obj.setValue(txt3.text!, forKey: "emp_mob");
                
                do
                {
                    try  context.save()
                    clear();
                }
                catch
                {
                }
            }
        }
        catch
        {
        }
    }
    @IBAction func btndelete(_ sender: Any)
    {
        let enity = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = enity;
        
        let pred = NSPredicate(format: "emp_name =%@", txt1.text!);
        
        request.predicate = pred;
        
        do
        {
            var arr  = try context.fetch(request);
            if arr.count > 0
            {
                
                let obj = arr[0] as! NSManagedObject;
                context.delete(obj);
                do
                {
                    try  context.save();
                    clear();
                }
                catch
                {
                }
            }
        }
        catch
        {
        }
        
    }
    
    @IBAction func btnselect(_ sender: Any)
    {
        let entity1 = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = entity1;
        
        let pred = NSPredicate(format: "emp_name =%@", txt1.text!);
        
        request.predicate = pred;
        
        
        do
        {
            var arr  = try context.fetch(request);
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject;
                
                txt1.text = obj.value(forKey: "emp_name") as! String?;
                txt2.text = obj.value(forKey: "emp_add") as! String?;
                txt3.text = obj.value(forKey: "emp_mob") as! String?
            }
        }
        catch
        {
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

