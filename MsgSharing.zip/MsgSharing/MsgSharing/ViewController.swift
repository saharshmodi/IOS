//
//  ViewController.swift
//  MsgSharing
//
//  Created by MAC2 on 18/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclick(_ sender: Any)
    {
        var arr : [Any] = [];
        arr.append("This is topstech");
        let alt = UIActivityViewController(activityItems: arr, applicationActivities: nil);
        self.present(alt, animated: true, completion: nil)
        
    }
    
}

