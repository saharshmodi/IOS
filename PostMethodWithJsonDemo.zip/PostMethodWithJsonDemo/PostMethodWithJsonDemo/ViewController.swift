//
//  ViewController.swift
//  PostMethodWithJsonDemo
//
//  Created by TOPS on 10/5/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate
{

    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func btnsearch(_ sender: Any)
    {
        let imgdata = UIImageJPEGRepresentation(img.image!, 2);
        let base64str = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        let url = URL(string: "http://localhost/sunny/index.php");
        let dic = ["emp_name":txt1.text!,"emp_img":base64str!];
        do
        {
            let jsondata = try JSONSerialization.data(withJSONObject: dic, options: []);
            var request = URLRequest(url: url!);
            request.addValue(String(jsondata.count), forHTTPHeaderField: "Content-Length");
            request.httpBody = jsondata;
            request.httpMethod = "POST";
            
            let session = URLSession.shared;
            let datatask = session.dataTask(with: request)
            {
                    (data1, resp, err) in
                    DispatchQueue.main.async
                    {
                        let strresp = String(data: data1!, encoding: String.Encoding.utf8);
                        self.lbl.text = strresp;
                    }
            }
            datatask.resume();
            
        }
        catch
        {
            
        }
    }
    
    
    @IBAction func btnimg(_ sender: Any)
    {
        let picker = UIImagePickerController();
        picker.sourceType = .photoLibrary;
        picker.delegate = self;
        self.present(picker, animated: true, completion: nil);
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage;
        img.image = img1;
        self.dismiss(animated: true, completion: nil);
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

