//
//  ViewController.swift
//  firebasedb
//
//  Created by MAC2 on 20/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtage: UITextField!
    
    var selectkey : String = ""
    var artistList = [ArtiestModel]()
    var refArtists = DatabaseReference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        refArtists = Database.database().reference().child("artists");

        getdata()
    }
    
    @IBAction func btninsert(_ sender: Any) {
        
        let key = refArtists.childByAutoId().key
        
        let artist = ["id":key,"artistName": txtempname.text! as String, "artistGenre": txtage.text! as String ]
        
        
        refArtists.child(key!).setValue(artist);
        getdata()
     
        
    }
    
    
    @IBAction func btnupdate(_ sender: Any)
    {
        if selectkey != ""
        {
            let artist = ["id":selectkey,"artistName": txtempname.text! as String, "artistGenre": txtage.text! as String ]
            
            
            refArtists.child(selectkey).setValue(artist);
            getdata()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return artistList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let artist : ArtiestModel
        
        artist = artistList[indexPath.row]
        
        cell.textLabel?.text = artist.name
        cell.detailTextLabel?.text = artist.age
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let artist : ArtiestModel
        
        artist = artistList[indexPath.row]
        
        txtempname.text = artist.name;
        txtage.text = artist.age;
        selectkey = artist.id!;
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        let artist : ArtiestModel
        
        artist = artistList[indexPath.row];
        refArtists.child(artist.id!).removeValue();
        getdata();
    }
    
    func getdata(){
        
        refArtists.observe(DataEventType.value, with: { (snapshot) in
            
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.artistList.removeAll()
                
                //iterating through all the values
                for artists in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let artistObject = artists.value as? [String: AnyObject]
                    let artistName  = artistObject?["artistName"]
                    let artistId  = artistObject?["id"]
                    let artistage = artistObject?["artistGenre"]
                    
                    //creating artist object with model and fetched values
                    let artist = ArtiestModel(id: artistId as! String?, name: artistName as! String?, age: artistage as! String?)
                    
                    //appending it to list
                    self.artistList.append(artist)
                }
                
                //reloading the tableview
                self.tbl.reloadData()
            }
        })
    }

}

