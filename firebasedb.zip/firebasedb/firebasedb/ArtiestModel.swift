//
//  File.swift
//  firebasedb
//
//  Created by MAC2 on 20/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import Foundation

class ArtiestModel {
    
    var id : String?
    var name : String?
    var age : String?
    
    init(id: String?, name: String?, age : String?) {
        
        self.id = id
        self.name = name
        self.age = age
        
    }
}
