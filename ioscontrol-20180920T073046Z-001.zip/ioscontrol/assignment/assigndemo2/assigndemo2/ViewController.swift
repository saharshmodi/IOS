//
//  ViewController.swift
//  assigndemo2
//
//  Created by TOPS on 8/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtnumber: UITextField!
    @IBOutlet weak var txtprice: UITextField!
    
    @IBOutlet weak var txtperiod: UITextField!
    
    @IBOutlet weak var txtroi: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //Write a program that calculates and prints the simple interest    `   using the Formula: Simple Interest = PNR / 100.
    @IBAction func count(_ sender: Any)
    {
        let p : Int = Int(txtprice.text!)!;
        let r : Int = Int(txtroi.text!)!;
        let n : Int = Int(txtperiod.text!)!;
        var  i : Double = Double(p * r * n);
        i = i / 100;
        let result = "\(i)";
        print( "Result : \(result)");
    }
    
    //Write a program to print Fibonacci series.
    @IBAction func fib(_ sender: Any)
    {
        let i:Int = Int(txtnumber.text!)!;
        var next = 1;
        var prev = 0;
        var n:Int = 0;
        print("\(prev)");
        while n <= i
        {
            print("\(next)");
            n = prev + next;
            prev = next;
            next = n;
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

