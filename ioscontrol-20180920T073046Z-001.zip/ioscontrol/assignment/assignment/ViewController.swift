//
//  ViewController.swift
//  assignment
//
//  Created by TOPS on 8/13/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtstrlen: UITextField!
    @IBOutlet weak var textname: UITextField!
    @IBOutlet weak var txtrno: UITextField!

    @IBOutlet weak var txtphp: UITextField!
    
    @IBOutlet weak var txtasp: UITextField!
    
    @IBOutlet weak var txtsname: UITextField!
    @IBOutlet weak var txtsid: UITextField!
    
    
    @IBOutlet weak var firststr: UITextField!
    
    @IBOutlet weak var secondstr: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    //4.Write a program that make tupple of two values integer and string and print it.
    @IBAction func len(_ sender: Any)
    {
        let str = txtstrlen.text!;
        
        print(str.characters.count);
        
    }
    
    
    //5.Write a program to make tupple for storing students result.
    @IBAction func btnresult(_ sender: Any)
    {
        let sname = textname.text!;
        let srno = Int(txtrno.text!)!;
        let php:Int = Int(txtphp.text!)!;
        let asp:Int = Int(txtasp.text!)!;
        let total:Int = (php + asp);
        let result = Double(total)/2;
        
        print("Name : \(sname)");
        print("Roll No : \(srno)");
        print("PHP : \(php) ASP : \(asp)");
        print("Total Marks : \(total)");
        print("Result : \(result)");
    }
    
    
   //3.Write a program to find out the length of given string.
    @IBAction func btnprint(_ sender: Any)
    {
        let tupple = (Int(txtsid.text!)!,txtsname.text!);
        print(tupple.0,tupple.1);
        print(tupple.0);
        print(tupple.1);
        
    }
    
    //2.Write a program to check whether two string are equal or not.if they are equal then concatenate them and append with ! and print it.
    @IBAction func compare(_ sender: Any)
    {
        
        let str1 = firststr.text!;
        let str2 = secondstr.text!;
        
        if str1 == str2
        {
            print("Both strings are same");
            var str3 = str1 + str2;
            str3.append("!");
            print("String : \(str3)");
        }
        else
        {
            print("Both Strings are Not same");
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

