//
//  ViewController.swift
//  gesture
//
//  Created by TOPS on 8/21/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var img: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let left = UISwipeGestureRecognizer(target: self, action: #selector(self.test))
        left.direction = .left
        
        img.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(left)
 
    }
    
    @objc func test(sender:UISwipeGestureRecognizer)
    {
        if sender.direction == .left
        {
            self.img.frame = CGRect(x: self.img.frame.origin.x-50, y: self.img.frame.origin.x-50, width: self.img.frame.size.width, height: self.img.frame.size.height)
        }
    }
}

