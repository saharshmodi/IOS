//
//  ViewController.swift
//  pickerviewdemo
//
//  Created by TOPS on 8/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var txt1: UITextField!
    let arr = ["ios",".net","php"];
    let arr1 = ["nt","unix","os"];
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txt1.text=arr[0];
        txt2.text=arr1[0];
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 2;
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0
        {
            return arr.count;
        }
        else
        {
            return arr1.count;
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0
        {
            return arr[row];
        }
        else
        {
            return arr1[row];
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if component == 0
        {
            self.txt1.text = arr[row];
        }
        else
        {
            self.txt2.text=arr1[row];
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

