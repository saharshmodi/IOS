//
//  ViewController.swift
//  imageview
//
//  Created by TOPS on 8/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclick(_ sender: Any)
    {
        let picker = UIImagePickerController()
        
        picker.sourceType = .photoLibrary
        picker.delegate = self
        
        self.present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        img.image = img1
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func btnnext(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next") as! ViewController1
        stb.arr = ["iOS","PHP"]
        
        self.navigationController?.pushViewController( stb, animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

