//
//  ViewController.swift
//  control
//
//  Created by TOPS on 8/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate
{
    @IBOutlet weak var txt2: UITextField!

    @IBOutlet weak var txt3: UITextField!
    
    @IBOutlet weak var dpicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dpicker.isHidden = true;
        let dt = Date();
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        txt3.text = frm.string(from: dt);
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true);
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return self.view.endEditing(true);
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if textField.tag == 1
        {
            dpicker.isHidden = true;
            return true;
        }
        else if textField.tag == 2
        {
            self.view.endEditing(true);
            alert();
            dpicker.isHidden = true;
            return false;
        }
        else
        {
            self.view.endEditing(true);
            dpicker.isHidden = false;
            return false;
        }

    }
    func alert()
    {
        let alt = UIAlertController(title: "Select", message: "select colour", preferredStyle: .actionSheet)
        
        let green = UIAlertAction(title: "Green", style: .default)
        {
            (alert) in
            self.txt2.backgroundColor = UIColor.green;
        }
        let red = UIAlertAction(title: "Red", style: .default)
        {
            (alert) in
            self.txt2.backgroundColor = UIColor.red;


        }
        let blue = UIAlertAction(title: "Blue", style: .default)
        {
            (alert) in
            self.txt2.backgroundColor = UIColor.blue;

            
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        {
            (alert) in
            print("Pressed cancel");
            
        }
        alt.addAction(green);
        alt.addAction(red);
        alt.addAction(blue);
        alt.addAction(cancel);
        self.present(alt, animated: true, completion: nil);


    }
    
    
    @IBAction func dpicker(_ sender: Any)
    {
        let dt = dpicker.date;
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        txt3.text = frm.string(from: dt);
        dpicker.isHidden = true;

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

