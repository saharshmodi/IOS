

import UIKit

class ViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource {

    var arrCity : [String] = ["Surat","Mumbai","Delhi"]
    
    @IBOutlet weak var dtPicker: UIDatePicker!
    @IBOutlet weak var lblDate: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        dtPicker.isHidden = true
            }

    @IBAction func txtDate(_ sender: UITextField) {
        
        dtPicker.isHidden = false
        
    }
    @IBAction func dtPicker(_ sender: UIDatePicker) {
        
        let dt = dtPicker.date
        let formator = DateFormatter()
        
        formator.dateFormat = "dd-MM-yyyy"
        
        lblDate.text = formator.string(from: dt)
        
        
    }

     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        return self.view.endEditing(true)
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrCity.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return arrCity[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        txtCity.text = arrCity[row]
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }


}

