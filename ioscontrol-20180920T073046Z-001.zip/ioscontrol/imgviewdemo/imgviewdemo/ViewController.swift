//
//  ViewController.swift
//  imgviewdemo
//
//  Created by TOPS on 8/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var imgview: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclick(_ sender: Any)
    {
        let picker = UIImagePickerController();
        
        picker.sourceType = .photoLibrary;
        picker.delegate = self;
        self.present(picker, animated: true, completion: nil);
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as!UIImage;
        imgview.image = img1;
        self.dismiss(animated: true, completion: nil);
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

