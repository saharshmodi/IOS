//
//  ViewController.swift
//  plistdemo
//
//  Created by TOPS on 10/9/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btncreate(_ sender: Any)
    {
        let dif = UserDefaults.standard;
        dif.set("101", forKey: "k1");
        
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let strpath = arr[0] as! String;
        
        let fullpath = strpath.appending("/profile.plist");
        
        print(fullpath);
        
        let fmg = FileManager();
        if !fmg.fileExists(atPath: fullpath)
        {
            let dic = ["fname":"Saharsh","lname":"Modi","phno":"7096617883"];
            let finaldic = NSDictionary(dictionary: dic);
            finaldic.write(toFile: fullpath, atomically: true);
        }
    }
    
    
    @IBAction func btndisp(_ sender: Any)
    {
        
        
        let dif = UserDefaults.standard;
        var dd = dif.value(forKey: "k1");
        print(dd);
        
        
        
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let strpath = arr[0] as! String;
        
        let fullpath = strpath.appending("/profile.plist");
        
        print(fullpath);
        
        let fmg = FileManager();
        if fmg.fileExists(atPath: fullpath)
        {
            let dic = NSDictionary(contentsOfFile: fullpath)
            print(dic);
        }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

