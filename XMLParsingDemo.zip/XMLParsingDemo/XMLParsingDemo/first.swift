//
//  first.swift
//  XMLParsingDemo
//
//  Created by TOPS on 9/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import SVProgressHUD

class first: UIViewController,UIWebViewDelegate
{

    var finalarr : [String] = [];
    
    @IBOutlet weak var web: UIWebView!
    
    @IBOutlet weak var txtview: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        SVProgressHUD.show();
        txtview.text = finalarr[2];
        let str = finalarr[1];
        let url = URL(string: str);
        web.loadRequest(URLRequest.init(url: url!));
        
        
        // Do any additional setup after loading the view.
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        SVProgressHUD.dismiss()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
