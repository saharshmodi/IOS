//
//  ViewController.swift
//  XMLParsingDemo
//
//  Created by TOPS on 9/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import SVProgressHUD

class ViewController: UIViewController,XMLParserDelegate,UITableViewDelegate,UITableViewDataSource
{
    var arr : [Any] = [];
    var brr : [String] = [];
    var strcontent = "";
    
    
    @IBOutlet weak var tblview: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        SVProgressHUD.show();
        
        let url = URL(string: "https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms");
        let reqeust = URLRequest(url: url!);
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: reqeust)
        {
            (data1, resp, err) in
            let parse = XMLParser(data: data1!);
            parse.delegate = self;
            parse.parse();
            
        }
        datatask.resume();
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func parserDidStartDocument(_ parser: XMLParser)
    {
        arr = [];
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        if elementName == "channel"
        {
            brr = [];
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if elementName == "title" || elementName == "link" || elementName == "description"
        {
            brr.append(strcontent);
        }
        else if elementName == "channel"
        {
            arr.append(brr);
        }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        strcontent = string;
    }
    func parserDidEndDocument(_ parser: XMLParser)
    {
        DispatchQueue.main.async
        {
            print(self.arr);
            self.tblview.reloadData();
            SVProgressHUD.dismiss()
        }
    }

    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        var title = arr[indexPath.row] as! [String];
        cell.textLabel?.text = title[0];
        return cell;
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next") as! first;
        let title = arr[indexPath.row] as! [String];
        stb.finalarr = title;
        self.navigationController?.pushViewController(stb, animated: true);
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

