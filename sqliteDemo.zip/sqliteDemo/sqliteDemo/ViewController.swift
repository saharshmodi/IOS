//
//  ViewController.swift
//  sqliteDemo
//
//  Created by TOPS on 10/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var txt3: UITextField!
    
    var arr : [Any] = [];
    
    @IBOutlet weak var tblview: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let db = dbclass();
        arr = db.getdata(strquery: "select * from emp");
        tblview.reloadData();
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count+1;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! Custcell;
        
        if indexPath.row == 0
        {
            cell.lbl1.text = "ID";
            cell.lbl2.text = "Name";
            cell.lbl3.text = "Address";
        }
        else
        {
            var temp = arr[indexPath.row-1] as! [String];
            cell.lbl1.text = temp[0] as! String;
            cell.lbl2.text = temp[1] as! String;
            cell.lbl3.text = temp[2] as! String;
        }
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.row != 0
        {
            var temp = arr[indexPath.row-1] as! [String];
        
            let i = temp[0];
            let db = dbclass();
            let arr1 = db.getdata(strquery: "select * from emp where emp_id='\(i)'");
            temp = arr1[0] as! [String];
        
            txt1.text = temp[0] as! String;
            txt2.text = temp[1] as! String;
            txt3.text = temp[2] as! String;
        }
    }
    
    @IBAction func btninsert(_ sender: Any)
    {
        let db = dbclass();
        let query = "insert into emp(emp_id,emp_name,emp_add)values('\(txt1.text!)','\(txt2.text!)','\(txt3.text!)')"
        let st = db.dml(query: query);
        if st == true
        {
            print("Record Inserted")
        }
        else
        {
            print("Record not Inserted");
        }
        clear();
        arr = db.getdata(strquery: "select * from emp");
        tblview.reloadData();
    }
    
    
    @IBAction func btnupdate(_ sender: Any)
    {
        let db = dbclass();
        let query = "update emp set emp_name= '\(txt2.text!)',emp_add='\(txt3.text!)' where emp_id = '\(txt1.text!)'";
        let st = db.dml(query: query);
        if st == true
        {
            print("Record Updated")
        }
        else
        {
            print("Record not Update");
        }
        clear()
        arr = db.getdata(strquery: "select * from emp");
        tblview.reloadData();
    }
    
    
    @IBAction func btndelete(_ sender: Any)
    
    {
        let db = dbclass();
        let query = "delete from emp where emp_id = '\(txt1.text!)'";
        let st = db.dml(query: query);
        if st == true
        {
            print("Record Deleted")
        }
        else
        {
            print("Record not Deleted");
        }
        clear();
        arr = db.getdata(strquery: "select * from emp");
        tblview.reloadData();

    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if indexPath.row != 0
        {
            var temp = arr[indexPath.row-1] as! [String];
            let i = temp[0];
            let db = dbclass();
            let query = "delete from emp where emp_id = '\(i)'";
            let st = db.dml(query: query);
            if st == true
            {
                print("Record Deleted")
            }
            else
            {
                print("Record not Deleted");
            }
            clear();
            arr = db.getdata(strquery: "select * from emp");
            tblview.reloadData();
        }
    }
    func clear()
    {
        txt1.text = "";
        txt2.text = "";
        txt3.text = "";
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

