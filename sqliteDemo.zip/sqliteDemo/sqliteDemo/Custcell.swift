//
//  Custcell.swift
//  sqliteDemo
//
//  Created by TOPS on 10/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class Custcell: UITableViewCell {

    
    @IBOutlet weak var lbl1: UILabel!
    
    
    @IBOutlet weak var lbl2: UILabel!
    
    @IBOutlet weak var lbl3: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
