//
//  ViewController.swift
//  TableViewWithAnimation
//
//  Created by TOPS on 9/10/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,CAAnimationDelegate,UITableViewDataSource,UITableViewDelegate {

    let arr = ["User Name","Acount","Change Profile","Change Password","Logout"]
    var tbl = UITableView()
    var navbar = UINavigationBar()
    override func viewDidLoad() {
        super.viewDidLoad()
        tbl = UITableView(frame: CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height), style: .grouped)
        tbl.dataSource = self
        tbl.delegate = self
        let right = UISwipeGestureRecognizer(target: self, action: #selector(self.click))
        let left = UISwipeGestureRecognizer(target: self, action: #selector(self.click))
        left.direction = .left
        right.direction = .right
        createNavigationBar()
        self.view.addGestureRecognizer(right)
        self.view.addGestureRecognizer(left)
        self.view.addSubview(tbl)
    }
    func createNavigationBar() {
        navbar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width ,height: 60))
        let navitem = UINavigationItem(title: "Ronit")
        let item = UIBarButtonItem(barButtonSystemItem: .bookmarks, target: self, action: #selector(self.click))
        navitem.leftBarButtonItem = item
        navbar.items = [navitem]
        self.view.addSubview(navbar)
    }
    func click() {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        if tbl.frame.size.width == 0
        {
            tbl.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width/2, height: self.view.frame.size.height)
            navbar.frame = CGRect(x: self.view.frame.size.width/2, y: 0, width: self.view.frame.size.width, height: 60)
        }
        else
        {
            tbl.frame = CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height)
            navbar.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 60)

        }
        UIView.commitAnimations()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = arr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row])
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height)
        navbar.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 60)
        UIView.commitAnimations()
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

