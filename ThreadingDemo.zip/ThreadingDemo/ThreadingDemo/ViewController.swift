//
//  ViewController.swift
//  ThreadingDemo
//
//  Created by MAC2 on 18/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet weak var img2: UIImageView!
    
    @IBOutlet weak var img3: UIImageView!
    
    @IBOutlet weak var img4: UIImageView!
    
    @IBOutlet weak var lblmsg: UILabel!
    
    let imgurl = ["https://images.unsplash.com/photo-1503249023995-51b0f3778ccf?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=warren-wong-346736-unsplash.jpg&s=01f172e507098d947ff1d142d54ade2f","https://images.unsplash.com/photo-1536905491217-7e9b8c1e226e?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=anita-austvika-1057079-unsplash.jpg&s=1f4e75d78e06b70dacc89fda057b4f4b","https://images.unsplash.com/photo-1475598322381-f1b499717dda?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=buzz-andersen-145254-unsplash.jpg&s=6d0e9c1fa82fafe6c0791e352e0361bb","https://images.unsplash.com/photo-1493087670264-2f7f5844b402?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=alex-246078-unsplash.jpg&s=2318fa0548616ec9079064efb87910b1"];
    
    class Downloader
    {
        class func downloadIMGwithURL(url:String) -> UIImage!
        {
            var dt = Data();
            do
            {
                dt = try! Data(contentsOf: URL(string:url)!)
            }
            catch
            {
                return nil;
            }
            return UIImage(data: dt);
        }
    }
    
    var queue = OperationQueue();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    /* OPERATION QUEUE */
    @IBAction func btnoperation(_ sender: Any)
    {
        queue = OperationQueue();
        let operation1 = BlockOperation (block:
        {
            let image1 = Downloader.downloadIMGwithURL(url: self.imgurl[0]);
            OperationQueue.main.addOperation ({
                self.img1.image = image1;
            })
        })
        queue.addOperation(operation1);
        
        let operation2 = BlockOperation (block:
        {
            let image2 = Downloader.downloadIMGwithURL(url: self.imgurl[1]);
            OperationQueue.main.addOperation ({
                self.img2.image = image2;
            })
        })
        operation2.addDependency(operation1);
        queue.addOperation(operation2);
        
        let operation3 = BlockOperation (block:
        {
            let image3 = Downloader.downloadIMGwithURL(url: self.imgurl[2]);
            OperationQueue.main.addOperation ({
                self.img3.image = image3;
            })
        })
        operation3.addDependency(operation2);
        queue.addOperation(operation3);
        
        let operation4 = BlockOperation (block:
        {
            let image4 = Downloader.downloadIMGwithURL(url: self.imgurl[3]);
            OperationQueue.main.addOperation ({
                self.img4.image = image4;
            })
        })
        queue.addOperation(operation4);
    }
    
    @IBAction func btncancel(_ sender: Any)
    {
        queue.cancelAllOperations();
    }
    
    @IBAction func slider(_ sender: Any)
    {
        self.lblmsg.text = "\((sender as AnyObject).value * 100.0)";
    }
    
    /*SERIAL QUEUE */
    @IBAction func btnserial(_ sender: Any)
    {
        let serialqueue = DispatchQueue(label: "com.appcoda.imagesqueue", attributes: []);
        serialqueue.async {
            () -> Void in
                let image1 = Downloader.downloadIMGwithURL(url: self.imgurl[0]);
            DispatchQueue.main.async(execute: {
                self.img1.image = image1;
            })
        }
        
        serialqueue.async {
            () -> Void in
            let image2 = Downloader.downloadIMGwithURL(url: self.imgurl[1]);
            DispatchQueue.main.async(execute: {
                self.img2.image = image2;
            })
        }
        
        serialqueue.async {
            () -> Void in
            let image3 = Downloader.downloadIMGwithURL(url: self.imgurl[2]);
            DispatchQueue.main.async(execute: {
                self.img3.image = image3;
            })
        }
        
        serialqueue.async {
            () -> Void in
            let image4 = Downloader.downloadIMGwithURL(url: self.imgurl[3]);
            DispatchQueue.main.async(execute: {
                self.img4.image = image4;
            })
        }
    }
}

