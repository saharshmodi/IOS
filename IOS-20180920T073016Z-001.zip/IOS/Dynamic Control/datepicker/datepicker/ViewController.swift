//
//  ViewController.swift
//  datepicker
//
//  Created by TOPS on 8/29/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var txt = UITextField()
        override func viewDidLoad() {
        super.viewDidLoad()
        createtb();
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true);
    }
    func createtb()
    {
        txt = UITextField(frame: CGRect(x: 20, y: 200, width: 100, height: 30));
        txt.placeholder = "Enter Date :";
        let dt = UIDatePicker(frame: CGRect(x: 0, y: self.view.frame.size.height-200, width: self.view.frame.size.width, height: 200));
        dt.datePickerMode = .date;
        dt.addTarget(self, action: #selector(self.test), for: .valueChanged);
        txt.inputView = dt;
        self.view.addSubview(txt);
    }
    func test(sender:UIDatePicker)
    {
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        txt.text = frm.string(from: sender.date);
        sender.isHidden = true;
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

