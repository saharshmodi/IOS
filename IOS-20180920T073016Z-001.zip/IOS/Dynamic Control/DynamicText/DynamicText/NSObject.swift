
import UIKit

class TextField: NSObject {

    func createText(frm : CGRect, placeholder : String, bordercolor : UIColor, bwidth : Int) -> UITextField
    {
            let txt = UITextField(frame: frm)
            txt.placeholder = placeholder
            txt.layer.cornerRadius = 10
            txt.clipsToBounds = true
            txt.layer.borderColor = bordercolor.cgColor
            txt.layer.borderWidth = CGFloat(bwidth)
            return txt
    }
}
