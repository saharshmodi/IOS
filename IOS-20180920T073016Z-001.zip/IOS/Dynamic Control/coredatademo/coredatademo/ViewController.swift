//
//  ViewController.swift
//  coredatademo
//
//  Created by TOPS on 8/30/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtempname: UITextField!
   
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
   
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func clear() {
        txtempname.text = "";
        txtempadd.text = "";
        txtempmob.text = "";
        
    }
    @IBAction func btnclick(_ sender: Any) {
        let newentity = NSEntityDescription.insertNewObject(forEntityName: "Employy", into: context)
        
        newentity.setValue(txtempname.text!, forKey: "emp_name");
        newentity.setValue(txtempadd.text!, forKey: "emp_add");
        newentity.setValue(txtempmob.text!, forKey: "emp_mob");
        
        do {
            try context.save();
            clear()
        } catch  {
            
        }
        
    }

    @IBAction func btnupdate(_ sender: Any) {
        let entity = NSEntityDescription.entity(forEntityName: "Employy", in: context);
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employy");
        
        let prid = NSPredicate(format: "emp_name = %@", txtempname.text!);
        
        request.predicate = prid;
        request.entity = entity;
        do {
            var arr = try context.fetch(request)
            
            if arr.count>0
            {
                let manage = arr[0] as! NSManagedObject;
                
                manage.setValue(txtempadd.text, forKey: "emp_add")
                manage.setValue(txtempmob.text, forKey: "emp_mob")
                
            }
        } catch {
            
        }
        do {
            try context.save();
            clear()
        } catch  {
            
        }
        
    }
    
    @IBAction func btndelete(_ sender: Any) {
        
        let entity = NSEntityDescription.entity(forEntityName: "Employy", in: context);
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employy");
        
        let prid = NSPredicate(format: "emp_name = %@", txtempname.text!);
        
        request.predicate = prid;
        request.entity = entity;
        do {
            var arr = try context.fetch(request)
            
            if arr.count>0
            {
                let manage = arr[0] as! NSManagedObject;
                
                context.delete(manage);
            }
        } catch {
            
        }
        do {
            try context.save();
            clear()
        } catch  {
            
        }
    }
    
    @IBAction func btnselect(_ sender: Any) {
        let entity = NSEntityDescription.entity(forEntityName: "Employy", in: context);
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employy");
        
        let prid = NSPredicate(format: "emp_name = %@", txtempname.text!);
        
        request.predicate = prid;
        request.entity = entity;
        do {
            var arr = try context.fetch(request)
        
            if arr.count>0
            {
                let manage = arr[0] as! NSManagedObject;
            
                txtempadd.text = manage.value(forKey: "emp_add") as! String?
    
                txtempmob.text = manage.value(forKey: "emp_mob") as! String?
                
                
                
                
            }
        } catch {
            
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

