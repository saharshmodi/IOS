//
//  ViewController.swift
//  segmentcontrol
//
//  Created by TOPS on 8/29/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        createseg();
        // Do any additional setup after loading the view, typically from a nib.
    }
    func createseg()
    {
        let arr = ["ios",".net","php","java"];
        let seg = UISegmentedControl(items: arr);
        seg .frame = CGRect(x: 20, y: 100, width: 200, height: 40);
        seg.addTarget(self, action: #selector(self.test), for: .valueChanged);
        self.view.addSubview(seg);
    }
    func test(sender:UISegmentedControl)
    {
        if sender.selectedSegmentIndex == 0
        {
            self.view.backgroundColor = UIColor.black;
        }
        else if sender.selectedSegmentIndex == 1
        {
            self.view.backgroundColor = UIColor.blue;
        }
        else if sender.selectedSegmentIndex == 2
        {
            self.view.backgroundColor = UIColor.brown;
        }
        else
        {
            self.view.backgroundColor = UIColor.cyan;
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

