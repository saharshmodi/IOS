//
//  ViewController.swift
//  pickerview
//
//  Created by TOPS on 8/29/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource{
    var txt = UITextField();
    let arr = ["ios","java","php","laravel"];
    override func viewDidLoad() {
        super.viewDidLoad()
        createtb();
        // Do any additional setup after loading the view, typically from a nib.
    }
    func createtb()
    {
        txt = UITextField(frame: CGRect(x: 20, y: 200, width: 100, height: 30));
        txt.placeholder = "Enter Date :";
        
        self.view.addSubview(txt);
        let picker = UIPickerView(frame: CGRect(x: 20, y: self.view.frame.size.height-200, width: self.view.frame.size.width, height: 200))
        picker.dataSource = self;
        picker.delegate = self;
        txt.inputView = picker;
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1;
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return arr.count;
    
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
            return arr[row];
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
            print(arr[row]);
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

