//
//  ViewController.swift
//  navigationbar
//
//  Created by TOPS on 8/29/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    var imgview = UIImageView();
    override func viewDidLoad() {
        super.viewDidLoad()
        createnavbar();
        createimgview();
        // Do any additional setup after loading the view, typically from a nib.
    }
    func createnavbar()
    {
        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 60));
        let navitem = UINavigationItem(title: "Employee");
        let bbitem = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(self.cameraopen));
        let btn = UIButton(type: .custom);
        btn.setImage(UIImage(named: "youtubeimg.png"), for: .normal);
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside);
        btn.frame = CGRect(x: 0, y: 0, width: 30, height: 30);
        let bbitem1 = UIBarButtonItem(customView: btn);
        navitem.rightBarButtonItem = bbitem;
        navitem.leftBarButtonItem = bbitem1;
        navbar.items = [navitem];
        self.view.addSubview(navbar);
    }
    func test(sender:UIBarButtonItem)
    {
        print("Click");
    }
    func cameraopen(sender:UIBarButtonItem)
    {
        let picker = UIImagePickerController();
        picker.sourceType = .photoLibrary;
        //picker.cameraDevice = .front;
        picker.delegate = self;
        self.present(picker, animated: true, completion: nil);
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img = info[UIImagePickerControllerOriginalImage]as!UIImage;
        imgview.image = img;
        self.view.addSubview(imgview)
        self.dismiss(animated: true, completion: nil)
    }
    func createimgview()
    {
        imgview = UIImageView(frame: CGRect(x: 10, y: 100, width: self.view.frame.size.width-50, height: 200));
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

