//
//  ViewController.swift
//  DynamicDemo
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttoncreate()
        
        let comm = NSObject1()
        let src = UIScrollView(frame: self.view.bounds)
        
        var y = 20
        for i  in 0...10
        {
            let btn = comm.createbutton(frm: CGRect(x: 20, y: y, width: 100, height: 100), color: nil, img: UIImage(named: "guju.png")!)
            btn.tag = i
            btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
            src.addSubview(btn)
            y = y + 120
        }
        src.contentSize = CGSize(width: self.view.frame.size.width, height: CGFloat(y))
        self.view.addSubview(src)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    func buttoncreate()
    {
        let btn = UIButton(type: .custom)
        btn.frame = CGRect(x: 20, y: 50, width: 100, height: 100)
        btn.setImage(UIImage(named : "guju.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        self.view.addSubview(btn)
    }
    
    func test(sender : UIButton)
    {
        print("Click")
        print(sender.tag)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

