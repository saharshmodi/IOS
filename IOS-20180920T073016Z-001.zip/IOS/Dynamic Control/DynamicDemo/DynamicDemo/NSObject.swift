//
//  NSObject.swift
//  DynamicDemo
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class NSObject1: NSObject{

    func createbutton(frm : CGRect, color : UIColor?, img : UIImage) -> UIButton {
        let btn = UIButton(type: .custom)
        btn.frame = frm
        btn.backgroundColor = color
        btn.setImage(img, for: .normal)
        return btn
    }
}
