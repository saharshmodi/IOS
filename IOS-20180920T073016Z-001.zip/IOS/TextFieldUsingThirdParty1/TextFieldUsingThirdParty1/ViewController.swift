//
//  ViewController.swift
//  TextFieldUsingThirdParty1
//
//  Created by TOPS on 9/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects

class ViewController: UIViewController
{
    var txt = KaedeTextField()
    var txt1 = HoshiTextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let frm = CGRect(x: 50, y: 50, width: 100, height: 30);
        txt = KaedeTextField(frame: frm);
        txt.placeholder = "Enter Name";
        txt.placeholderColor = .darkGray;
        txt.foregroundColor = .yellow;
        self.view.addSubview(txt);
        
        let frm1 = CGRect(x: 50, y: 100, width: 100, height: 30);
        txt1 = HoshiTextField(frame: frm1);
        txt1.placeholder = "Enter City";
        txt1.placeholderColor = .cyan;
        let border = CALayer()
        let width = CGFloat(2.0);
        border.borderColor = UIColor.blue.cgColor;
        border.frame = CGRect(x: 0, y: txt1.frame.size.height-width, width: txt1.frame.size.width, height: txt1.frame.size.height)
        border.borderWidth = width;
        txt1.layer.addSublayer(border);
        txt1.layer.masksToBounds = true;
        self.view.addSubview(txt1);
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

