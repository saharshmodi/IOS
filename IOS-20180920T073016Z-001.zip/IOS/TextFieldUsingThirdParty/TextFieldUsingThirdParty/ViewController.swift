//
//  ViewController.swift
//  TextFieldUsingThirdParty
//
//  Created by TOPS on 9/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects
class ViewController: UIViewController {

    var txt4 = IsaoTextField()
    var border = CALayer()
    var width = CGFloat(3.0)

    override func viewDidLoad() {
        super.viewDidLoad()
        let frm = CGRect(x: 50, y: 50, width: 200, height: 40)
        let txt = KaedeTextField(frame: frm)
        txt.placeholder = "Enter Fname"
        txt.placeholderColor = .darkGray
        txt.foregroundColor = UIColor.yellow
               let txt2 = HoshiTextField(frame: CGRect(x: 50, y: 140, width: 200, height: 40))
        txt2.placeholder = "Enter Lname"
        txt2.layer.borderWidth = 1
        let txt3 = AkiraTextField(frame: CGRect(x: 50, y: 230, width: 200, height: 40))
        txt3.placeholder = "Enter Name"
        txt4 = IsaoTextField(frame: CGRect(x: 50, y: 320, width: 200, height: 60))
        txt4.placeholder = "Enter Name"
        border = CALayer()
        width = CGFloat(3.0)
        border.frame = CGRect(x: 0, y: txt4.frame.size.height-width-15, width: txt4.frame.size.width, height: 3)
        border.borderWidth = CGFloat(width)
        txt4.layer.addSublayer(border)
        border.borderColor = UIColor.gray.cgColor
        txt4.layer.masksToBounds = true
        txt4.tintColor = UIColor.gray
        border.borderColor = UIColor.gray.cgColor
        txt4.addTarget(self, action: #selector(self.click4), for: .touchDown)
        self.view.addSubview(txt)
        self.view.addSubview(txt2)
        self.view.addSubview(txt3)
        self.view.addSubview(txt4)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        border.frame = CGRect(x: 0, y: txt4.frame.size.height-width-15, width: txt4.frame.size.width, height: 3)
        border.borderColor = UIColor.gray.cgColor
        border.borderWidth = CGFloat(3.0)
        self.view.endEditing(true)
    }
    func click4(sender : IsaoTextField) {
        border.frame = CGRect(x: 0, y: txt4.frame.size.height-width-17, width: txt4.frame.size.width, height: 5)
        border.borderColor = UIColor.red.cgColor
        border.borderWidth = CGFloat(4.0)
        self.view.endEditing(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

