//
//  ViewController.swift
//  jsonparsingcodingDemo
//
//  Created by TOPS on 9/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate
{

    
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lblcode: UILabel!
    
    @IBOutlet weak var txt: UITextField!
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var tblview: UITableView!
    var trainname = ["AHMADABAD PASS","RAJDHANI EXP","OKHA VG PASS","PADMAVAT EXPRES"];
    var trainnameindex = ["AHMADABAD PASS":"59439","RAJDHANI EXP":"12433","OKHA VG PASS":"59504","PADMAVAT EXPRES":"14208"];
    
    var arr : [Any] = [];
    override func viewDidLoad()
    {
        
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell;
        
        let temp = arr[indexPath.row] as! [String:Any];
        let dic = temp["station"] as! [String:Any];
        
        cell.lblstname.text = dic["name"] as? String;
        cell.lblarrdate.text = temp["actarr_date"] as? String;
        cell.lbldept.text = temp["schdep"] as? String;
        cell.lblstatus.text = temp["status"] as? String;
        
        return cell;
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1;
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return trainname.count;
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return trainname[row];
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        txt.text = trainname[row];
        picker.isHidden = true;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    @IBAction func txtclick(_ sender: Any)
    {
        picker.isHidden = false;
    }
    @IBAction func btnclick(_ sender: Any)
    {
        if txt.text != ""
        {
        
        let traincode:String = trainnameindex[txt.text!]!;
        let url = URL(string: "https://api.railwayapi.com/v2/live/train/\(traincode)/date/14-09-2018/apikey/c2xfmda0ac/");
        do
        {
            let dt = try Data(contentsOf: url!)
            do
            {
                let jsondata = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any];
                
                let curr = jsondata["current_station"] as! [String:Any];
                
                lblname.text = curr["name"] as? String;
                lblcode.text = curr["code"] as? String;
                
                arr = jsondata["route"] as! [[String:Any]];
                tblview.reloadData();
            }
            catch
            {
                
            }
        }
        catch
        {
            
        }
        }
        
 
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if textField.tag == 1
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}

