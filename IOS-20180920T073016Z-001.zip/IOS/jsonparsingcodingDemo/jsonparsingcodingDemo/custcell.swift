//
//  custcell.swift
//  jsonparsingcodingDemo
//
//  Created by TOPS on 9/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    
    @IBOutlet weak var lblstname: UILabel!
    
    @IBOutlet weak var lblarrdate: UILabel!
    
    @IBOutlet weak var lbldept: UILabel!
    
    @IBOutlet weak var lblstatus: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
