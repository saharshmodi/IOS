//
//  ViewLiveTrainStatus.swift
//  JsonDemoBackgroundMethodAllApi
//
//  Created by TOPS on 9/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import SVProgressHUD
class ViewLiveTrainStatus: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {

    @IBOutlet weak var lblStName: UILabel!
    
    @IBOutlet weak var lblStCode: UILabel!
    
    @IBOutlet weak var tblLiveTrainStatus: UITableView!
    @IBOutlet weak var txtSelectTrain: UITextField!
   
    @IBOutlet weak var picker: UIPickerView!
    var route:[Any] = []
    
    let trainName = ["Ahmadabad Pass","Bhavanagr Exp","Gujarat Queen","Himalyan Queen","Rajdhani Exp"]
    let trainNamecode = ["Ahmadabad Pass":"59439","Bhavanagr Exp":"12971","Gujarat Queen":"19033","Himalyan Queen":"52456","Rajdhani Exp":"12433"]
    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show()
        let url = URL(string: "https://api.railwayapi.com/v2/live/train/19033/date/17-09-2018/apikey/makp8tpb5p/")
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: request) { (data, resp, err) in
            
            do
            {
                let jsonData = try JSONSerialization.jsonObject(with: data!, options: []) as! [String:Any]
                
                DispatchQueue.main.async {
                    
                    SVProgressHUD.dismiss()
                    
                    
                    self.route = jsonData["route"] as! [Any]
                    let currentStDetails = jsonData["current_station"] as! [String:Any]
                    self.lblStName.text = currentStDetails["name"] as! String
                    self.lblStCode.text = currentStDetails["code"] as! String
                    self.tblLiveTrainStatus.reloadData()
                }
            }
            catch
            {
                
            }
            
        }
        dataTask.resume()
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return false
    }
    @IBAction func txtSelectAction(_ sender: Any) {
    }
    @IBAction func SearchAction(_ sender: Any) {
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return route.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustCellLiveTrainStatus
        
        let temp = route[indexPath.row] as! [String:Any]
        let st = temp["station"] as! [String:Any]
        
        cell.lblstname.text = st["name"] as! String
        
        cell.lblstcode.text = st["code"] as! String
        
        cell.lblstatus.text = temp["status"] as! String
        
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "All Routes"
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
