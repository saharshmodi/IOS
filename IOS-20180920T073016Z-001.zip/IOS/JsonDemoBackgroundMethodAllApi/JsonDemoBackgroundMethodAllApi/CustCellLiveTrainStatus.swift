//
//  CustCellLiveTrainStatus.swift
//  JsonDemoBackgroundMethodAllApi
//
//  Created by TOPS on 9/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class CustCellLiveTrainStatus: UITableViewCell {

    @IBOutlet weak var lblstname: UILabel!
    
    @IBOutlet weak var lblstcode: UILabel!
    @IBOutlet weak var lblstatus: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
