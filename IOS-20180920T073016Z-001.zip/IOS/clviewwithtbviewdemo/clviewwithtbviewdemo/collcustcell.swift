//
//  collcustcell.swift
//  clviewwithtbviewdemo
//
//  Created by TOPS on 9/7/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class collcustcell: UICollectionViewCell {
    
    @IBOutlet weak var img2: UIImageView!
}
