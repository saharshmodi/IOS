//
//  custcell1.swift
//  clviewwithtbviewdemo
//
//  Created by TOPS on 9/7/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell1: UITableViewCell {

    @IBOutlet weak var img1: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
