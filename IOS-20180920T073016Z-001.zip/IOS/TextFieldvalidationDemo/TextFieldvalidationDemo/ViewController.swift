//
//  ViewController.swift
//  TextFieldvalidationDemo
//
//  Created by TOPS on 9/10/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

let  REGEX_USER_NAME_LIMIT = "^.{3,10}$";
let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}";
let  REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
let REGEX_PASSWORD_LIMIT = "^.{6,20}$";
let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}";
let REGEX_PHONE_DEFAULT = "[0-9]{10}";


class ViewController: UIViewController {

    
    @IBOutlet weak var txtuname: TextFieldValidator!
    
    @IBOutlet weak var txtpass: TextFieldValidator!
    
    @IBOutlet weak var txtphno: TextFieldValidator!
    
    @IBOutlet weak var txtemail: TextFieldValidator!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setValidate()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func setValidate()
    {
        txtuname.addRegx(REGEX_USER_NAME, withMsg: "username limit should be 3 to 10 char")
        txtuname.presentInView = self.view;
        txtpass.addRegx(REGEX_PASSWORD, withMsg: "password limit should be 6 to 20 char");
        txtpass.presentInView = self.view;
        txtemail.addRegx(REGEX_EMAIL, withMsg: "email address is wrong");
        txtemail.presentInView = self.view;
        txtphno.addRegx(REGEX_PHONE_DEFAULT, withMsg: "enter valid mob ");
        txtphno.presentInView = self.view;
    }
    
    func validate1() -> Bool
    {
        if txtuname.validate() && txtpass.validate() && txtphno.validate() && txtemail.validate()
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    @IBAction func btnsubmit(_ sender: Any)
    {
        if validate1()
        {
            print("Submit");
        }
        else
        {
            print("Not Submitted");
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

