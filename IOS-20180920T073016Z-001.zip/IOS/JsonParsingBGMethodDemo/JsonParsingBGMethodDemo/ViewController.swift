//
//  ViewController.swift
//  JsonParsingBGMethodDemo
//
//  Created by TOPS on 9/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var arr : [Any] = [];

    @IBOutlet weak var tblview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://api.railwayapi.com/v2/name-to-code/station/bardoli/apikey/c2xfmda0ac/");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request)
        {
            (data1, request1, err) in
            do
            {
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [String:Any];
                
                DispatchQueue.main.async
                {
                    self.arr = jsondata["stations"] as! [Any];
                    self.tblview.reloadData();
                }
            }
            catch
            {
            }
        }
        datatask.resume();
    // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        let temp = arr[indexPath.row] as! [String:Any];
        
        cell.textLabel?.text = temp["name"] as! String;
        cell.textLabel?.text = temp["code"] as! String;
        
        return cell;
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

