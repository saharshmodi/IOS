
import UIKit

class ViewController: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,CAAnimationDelegate
{
    var txt = UITextField()
    var tblview = UITableView()
    let arr = ["Surat","Baroda","Anand","Bharuch"];
    //var time = Timer()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        txt = UITextField(frame: CGRect(x: 50, y: 50, width: 150, height: 50));
        txt.placeholder = "Select City";
        txt.addTarget(self, action: #selector(self.test), for: .touchDown);
        txt.tag = 1;
        txt.delegate = self;
        tblview = UITableView(frame: CGRect(x: 50, y: 100, width: 200, height: 0),style: .grouped);
        tblview.delegate = self;
        tblview.dataSource = self;
        self.view.addSubview(txt);
        self.view.addSubview(tblview);
        
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField.tag == 1
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true);
    }
    func test(sender:UITextField)
    {
        UIView.beginAnimations(nil, context: nil);
        UIView.setAnimationDuration(2.5);
        UIView.setAnimationDelegate(self);
        tblview.frame = CGRect(x: 50, y: 100, width: 200, height: 200);
        UIView.commitAnimations();
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell");
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        cell.textLabel?.text = arr[indexPath.row];
        print(arr[indexPath.row]);
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        txt.text = arr[indexPath.row];
        UIView.beginAnimations(nil, context: nil);
        UIView.setAnimationDuration(2.5);
        UIView.setAnimationDelegate(self);
        tblview.frame = CGRect(x: 50, y: 100, width: 200, height: 0);
        UIView.commitAnimations();
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

