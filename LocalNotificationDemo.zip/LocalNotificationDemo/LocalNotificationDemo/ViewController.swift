//
//  ViewController.swift
//  LocalNotificationDemo
//
//  Created by MAC2 on 18/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationsetupcheck()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func notificationsetupcheck()
    {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert])
        { (success, error) in
            if success
            {
                print("success");
            }
            else
            {
                print("error")
            }
        }
    }
    
    @IBAction func btnclick(_ sender: Any)
    {
        let notification = UNMutableNotificationContent();
        notification.title = "Important Meeting";
        notification.subtitle = "At 2:00PM";
        notification.body = "With CEO of Tata group of comapnies";
        
        let notificationtrigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false);
        let request = UNNotificationRequest(identifier: "Message for u", content: notification, trigger: notificationtrigger);
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil);
    }
    
}

