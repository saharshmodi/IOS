//
//  ViewController.swift
//  FoodOrderingSystem
//
//  Created by MAC2 on 11/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var time = Timer()
    var a = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        img.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        time = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.test), userInfo: nil, repeats: true)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var img: UIImageView!
    
    @objc func test(sender:Timer) {
        
        if a < 5
        {
         a = a + 1
            print(a)
        }
        else
        {
            time.invalidate()
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Login")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
}

